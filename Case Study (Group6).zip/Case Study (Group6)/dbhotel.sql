-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2024 at 09:09 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbhotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `addetails`
--

CREATE TABLE `addetails` (
  `reservationID` int(50) NOT NULL,
  `adOn_typeID` varchar(251) NOT NULL,
  `Price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addetails`
--

INSERT INTO `addetails` (`reservationID`, `adOn_typeID`, `Price`) VALUES
(1010, 'A01', 5200),
(1010, 'A02', 500),
(1010, 'A03', 200),
(1011, 'A01', 7800),
(1011, 'A02', 1250),
(1011, 'A03', 600),
(1011, 'A04', 1400),
(1017, 'A01', 650),
(1017, 'A02', 250),
(1017, 'A03', 100),
(1017, 'A04', 200),
(1018, 'A01', 650),
(1018, 'A02', 250),
(1018, 'A03', 100),
(1021, 'A01', 650),
(1021, 'A02', 1250),
(1021, 'A03', 500),
(1021, 'A04', 1000),
(1022, 'A01', 650),
(1022, 'A02', 250),
(1022, 'A03', 500),
(1022, 'A04', 200),
(1029, 'A01', 650),
(1029, 'A02', 250),
(1029, 'A03', 100),
(1029, 'A04', 200),
(1033, 'A01', 650),
(1033, 'A02', 250),
(1033, 'A03', 100),
(1033, 'A04', 200),
(1034, 'A01', 650),
(1034, 'A02', 1250),
(1034, 'A03', 400),
(1034, 'A04', 1000),
(1035, 'A01', 650),
(1035, 'A02', 250),
(1035, 'A03', 100),
(1035, 'A04', 200),
(1036, 'A01', 1950),
(1036, 'A02', 250),
(1036, 'A03', 100);

-- --------------------------------------------------------

--
-- Table structure for table `adons`
--

CREATE TABLE `adons` (
  `adOn_typeID` varchar(251) NOT NULL,
  `adOns_Type` varchar(251) NOT NULL,
  `Rate` varchar(251) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adons`
--

INSERT INTO `adons` (`adOn_typeID`, `adOns_Type`, `Rate`) VALUES
('A01', 'Bed', '650'),
('A02', 'Blanket', '250'),
('A03', 'Pillow', '100'),
('A04', 'Toiletries', '200');

-- --------------------------------------------------------

--
-- Table structure for table `amenities`
--

CREATE TABLE `amenities` (
  `ame_typeID` varchar(251) NOT NULL,
  `amenities_Type` varchar(251) NOT NULL,
  `Price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `amenities`
--

INSERT INTO `amenities` (`ame_typeID`, `amenities_Type`, `Price`) VALUES
('B01', 'Swimming Pool', 300),
('B02', 'Gym', 500),
('B03', 'Foot Spa', 825),
('B04', 'Aroma Facial Spa', 1045),
('B05', 'Thai Massage', 1540);

-- --------------------------------------------------------

--
-- Table structure for table `amenities_details`
--

CREATE TABLE `amenities_details` (
  `reservationID` int(50) NOT NULL,
  `ame_typeID` varchar(251) NOT NULL,
  `Price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `amenities_details`
--

INSERT INTO `amenities_details` (`reservationID`, `ame_typeID`, `Price`) VALUES
(1013, 'B02', 500),
(1013, 'B03', 825),
(1013, 'B04', 6270),
(1013, 'B04', 0),
(1017, 'B01', 300),
(1017, 'B02', 500),
(1017, 'B03', 825),
(1017, 'B04', 1045),
(1017, 'B05', 1540),
(1017, 'B01', 300),
(1017, 'B03', 825),
(1017, 'B04', 1045),
(1017, 'B04', 0),
(1018, 'B01', 300),
(1018, 'B02', 500),
(1018, 'B03', 2475),
(1018, 'B04', 1045),
(1018, 'B04', 0),
(1026, 'B01', 300),
(1026, 'B02', 500),
(1026, 'B03', 825),
(1026, 'B04', 1045),
(1026, 'B05', 1540),
(1026, 'B01', 300),
(1026, 'B02', 500),
(1026, 'B03', 825),
(1026, 'B04', 1045),
(1026, 'B05', 1540),
(1026, 'B04', 0),
(1029, 'B01', 300),
(1029, 'B04', 1045),
(1029, 'B05', 1540),
(1029, 'B04', 0),
(1036, 'B01', 300),
(1036, 'B02', 500),
(1036, 'B03', 825),
(1036, 'B01', 300),
(1036, 'B02', 500),
(1036, 'B03', 825),
(1036, 'B01', 300),
(1036, 'B02', 500),
(1036, 'B05', 1540),
(1038, 'B01', 300),
(1038, 'B02', 500),
(1038, 'B03', 825),
(1038, 'B04', 1045),
(1038, 'B05', 1540),
(1038, 'B01', 300),
(1038, 'B02', 500),
(1038, 'B03', 825),
(1038, 'B04', 1045),
(1038, 'B05', 1540),
(1038, 'B04', 0);

-- --------------------------------------------------------

--
-- Table structure for table `destinationdetails`
--

CREATE TABLE `destinationdetails` (
  `dTypeID` varchar(251) NOT NULL,
  `destinationType` varchar(251) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `destinationdetails`
--

INSERT INTO `destinationdetails` (`dTypeID`, `destinationType`) VALUES
('D01', 'Local'),
('D02', 'International');

-- --------------------------------------------------------

--
-- Table structure for table `paymentdetails`
--

CREATE TABLE `paymentdetails` (
  `paymentID` int(50) NOT NULL,
  `reservationID` int(50) NOT NULL,
  `roomPrice_ID` int(50) NOT NULL,
  `payMethod` varchar(251) NOT NULL,
  `number` varchar(251) NOT NULL,
  `payable` int(50) NOT NULL,
  `payment` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `paymentdetails`
--

INSERT INTO `paymentdetails` (`paymentID`, `reservationID`, `roomPrice_ID`, `payMethod`, `number`, `payable`, `payment`) VALUES
(3140000, 1013, 0, 'GCash', '9982832054', 12595, 12595),
(3140001, 1018, 0, 'GCash', '9982832054', 10320, 10320),
(3140002, 1026, 0, 'GCash', '9982832054', 13420, 894),
(3140003, 1027, 0, 'GCash', '9982832054', 5000, 5000),
(3140004, 1029, 4020, 'GCash', '9982832054', 9085, 9085),
(3140005, 1036, 4024, 'Credit Card', '1111222233334444', 26890, 27000);

-- --------------------------------------------------------

--
-- Table structure for table `ratedetails`
--

CREATE TABLE `ratedetails` (
  `rateID` varchar(251) NOT NULL,
  `seasonID` varchar(251) NOT NULL,
  `roomtype_ID` varchar(251) NOT NULL,
  `dTYpeID` varchar(251) NOT NULL,
  `roomType` varchar(251) NOT NULL,
  `Price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ratedetails`
--

INSERT INTO `ratedetails` (`rateID`, `seasonID`, `roomtype_ID`, `dTYpeID`, `roomType`, `Price`) VALUES
('E01', 'S03', 'R01', 'D01', 'Standard', 12000),
('E02', 'S03', 'R02', 'D01', 'Deluxe', 16000),
('E03', 'S03', 'R03', 'D01', 'Quadruple', 20000),
('E04', 'S03', 'R04', 'D01', 'Family', 24000),
('E05', 'S03', 'R05', 'D01', 'Suite', 28000),
('I01', 'S03', 'R01', 'D02', 'Standard', 13000),
('I02', 'S03', 'R02', 'D02', 'Deluxe', 18000),
('I03', 'S03', 'R03', 'D02', 'Quadruple', 23000),
('I04', 'S03', 'R04', 'D02', 'Family', 28000),
('I05', 'S03', 'R05', 'D02', 'Suite', 33000),
('P01', 'S04', 'R01', 'D02', 'Standard', 20000),
('P02', 'S04', 'R02', 'D02', 'Deluxe', 26000),
('P03', 'S04', 'R03', 'D02', 'Quadruple', 32000),
('P04', 'S04', 'R04', 'D02', 'Family', 38000),
('P05', 'S04', 'R05', 'D02', 'Suite', 44000),
('Q01', 'S01', 'R01', 'D01', 'Standard', 2000),
('Q02', 'S01', 'R02', 'D01', 'Deluxe', 3000),
('Q03', 'S01', 'R03', 'D01', 'Quadruple', 4000),
('Q04', 'S01', 'R04', 'D01', 'Family', 5000),
('Q05', 'S01', 'R05', 'D01', 'Suite', 6000),
('T01', 'S04', 'R01', 'D01', 'Standard', 18000),
('T02', 'S04', 'R02', 'D01', 'Deluxe', 24000),
('T03', 'S04', 'R03', 'D01', 'Quadruple', 30000),
('T04', 'S04', 'R04', 'D01', 'Family', 36000),
('T05', 'S04', 'R05', 'D01', 'Suite', 42000),
('U01', 'S02', 'R01', 'D02', 'Standard', 9000),
('U02', 'S02', 'R02', 'D02', 'Deluxe', 14000),
('U03', 'S02', 'R03', 'D02', 'Quadruple', 19000),
('U04', 'S02', 'R04', 'D02', 'Family', 24000),
('U05', 'S02', 'R05', 'D02', 'Suite', 29000),
('W01', 'S02', 'R01', 'D01', 'Standard', 4000),
('W02', 'S02', 'R02', 'D01', 'Deluxe', 5000),
('W03', 'S02', 'R03', 'D01', 'Quadruple', 7000),
('W04', 'S02', 'R04', 'D01', 'Family', 9000),
('W05', 'S02', 'R05', 'D01', 'Suite', 11000),
('Y01', 'S01', 'R01', 'D02', 'Standard', 5000),
('Y02', 'S01', 'R02', 'D02', 'Deluxe', 10000),
('Y03', 'S01', 'R03', 'D02', 'Quadruple', 15000),
('Y04', 'S01', 'R04', 'D02', 'Family', 20000),
('Y05', 'S01', 'R05', 'D02', 'Suite', 24000);

-- --------------------------------------------------------

--
-- Table structure for table `reservationdetails`
--

CREATE TABLE `reservationdetails` (
  `reservationID` int(50) NOT NULL,
  `accNum` int(50) NOT NULL,
  `origin` varchar(251) NOT NULL,
  `destination` varchar(251) NOT NULL,
  `checkIn` date NOT NULL,
  `checkOut` date NOT NULL,
  `numGuest` int(50) NOT NULL,
  `roomType` varchar(251) NOT NULL,
  `season` varchar(251) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservationdetails`
--

INSERT INTO `reservationdetails` (`reservationID`, `accNum`, `origin`, `destination`, `checkIn`, `checkOut`, `numGuest`, `roomType`, `season`) VALUES
(1001, 13660002, 'Manila', 'Baguio', '2024-05-31', '2024-07-01', 5, 'Quadruple', 'Peak'),
(1002, 13660002, 'Manila', 'Hong Kong', '2024-05-31', '2024-07-01', 1, '', 'Peak'),
(1003, 13660002, 'Manila', 'Hong Kong', '2024-05-31', '2024-06-01', 1, 'Standard', 'Peak'),
(1004, 13660003, 'Manila', 'Baguio', '2024-06-03', '2024-07-01', 3, 'Deluxe', 'Lean'),
(1005, 13660003, 'Manila', 'Hong Kong', '2024-10-01', '2024-12-01', 0, '', 'Lean'),
(1006, 13660003, 'Manila', 'Hong Kong', '2024-12-01', '2025-01-01', 6, 'Family', 'High'),
(1007, 13660003, 'Manila', 'El Nido', '2025-03-01', '2025-05-01', 1, 'Standard', 'Peak'),
(1008, 13660003, 'Manila', 'South Korea', '2024-12-27', '2025-01-01', 1, 'Standard', 'Super Peak'),
(1009, 13660003, 'Manila', 'Hong Kong', '2024-06-03', '2024-06-04', 1, 'Standard', 'Lean'),
(1010, 13660003, 'Manila', 'Singapore', '2024-12-01', '2024-12-09', 3, 'Deluxe', 'High'),
(1011, 13660003, 'Manila', 'Hong Kong', '2024-12-20', '2025-01-01', 6, 'Family', 'Super Peak'),
(1012, 13660003, 'Manila', 'Hong Kong', '2024-11-01', '2024-11-09', 2, 'Standard', 'Super Peak'),
(1013, 13660003, 'Manila', 'Hong Kong', '2024-06-03', '2024-06-04', 1, 'Standard', 'Lean'),
(1014, 13660003, 'Manila', 'Hong Kong', '2024-07-01', '2024-10-01', 0, '', 'Lean'),
(1015, 13660003, 'Manila', 'Hong Kong', '2024-06-03', '2024-06-04', 0, '', 'Lean'),
(1016, 13660003, '', '', '0001-01-01', '0001-01-01', 0, '', ''),
(1017, 13660003, 'Manila', 'Hong Kong', '2024-06-03', '2024-06-04', 2, 'Standard', 'Lean'),
(1018, 13660003, 'Manila', 'Hong Kong', '2024-06-03', '2024-06-04', 1, 'Standard', 'Lean'),
(1019, 13660003, 'Manila', 'Hong Kong', '2024-06-03', '2024-06-04', 0, '', 'Lean'),
(1020, 13660003, 'Manila', 'Hong Kong', '2024-06-03', '2024-06-04', 0, '', 'Lean'),
(1021, 13660003, 'Manila', 'Baguio', '2024-06-03', '2024-06-04', 2, 'Standard', 'Lean'),
(1022, 13660003, 'Manila', 'Hong Kong', '2024-06-03', '2024-06-04', 2, 'Standard', 'Lean'),
(1023, 13660003, 'Manila', 'Hong Kong', '2024-06-03', '2024-06-04', 1, 'Standard', 'Lean'),
(1024, 13660003, 'Manila', 'Hong Kong', '2024-06-03', '2024-06-04', 1, 'Standard', 'Lean'),
(1025, 13660003, 'Manila', 'Baguio', '2024-06-03', '2024-06-04', 2, 'Standard', 'Lean'),
(1026, 13660003, 'Manila', 'Hong Kong', '2024-06-03', '2024-06-04', 2, 'Standard', 'Lean'),
(1027, 13660003, 'Manila', 'Hong Kong', '2024-06-03', '2024-06-04', 1, 'Standard', 'Lean'),
(1028, 13660003, '', '', '0001-01-01', '0001-01-01', 0, '', ''),
(1029, 13660003, 'Manila', 'Hong Kong', '2024-06-04', '2024-06-05', 1, 'Standard', 'Lean'),
(1030, 13660003, 'Manila', 'South Korea', '2024-06-04', '2024-06-05', 1, '', 'Lean'),
(1031, 13660003, 'Manila', 'Baguio', '2024-06-04', '2024-06-05', 1, '', 'Lean'),
(1032, 13660003, 'Manila', 'Hong Kong', '2024-06-04', '2024-06-05', 1, '', 'Lean'),
(1033, 13660003, 'Manila', 'Hong Kong', '2024-06-04', '2024-06-05', 2, 'Standard', 'Lean'),
(1034, 13660003, 'Manila', 'Hong Kong', '2024-06-04', '2024-06-05', 2, 'Standard', 'Lean'),
(1035, 13660003, 'Manila', 'Hong Kong', '2024-06-04', '2024-06-05', 2, 'Standard', 'Lean'),
(1036, 13660007, 'Manila', 'Hong Kong', '2024-12-01', '2024-12-04', 5, 'Quadruple', 'High'),
(1037, 13660003, 'Manila', 'Hong Kong', '2024-06-09', '2024-06-10', 1, 'Standard', 'Lean'),
(1038, 13660003, 'Manila', 'Hong Kong', '2024-06-09', '2024-06-10', 2, 'Standard', 'Lean');

-- --------------------------------------------------------

--
-- Table structure for table `roomdetails`
--

CREATE TABLE `roomdetails` (
  `roomtype_ID` varchar(251) NOT NULL,
  `roomType` varchar(251) NOT NULL,
  `Capacity` int(50) NOT NULL,
  `roomAvailable` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roomdetails`
--

INSERT INTO `roomdetails` (`roomtype_ID`, `roomType`, `Capacity`, `roomAvailable`) VALUES
('R01', 'Standard', 2, 5),
('R02', 'Deluxe', 3, 4),
('R03', 'Quadruple', 5, 5),
('R04', 'Family', 7, 3),
('R05', 'Suite', 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `roomprice`
--

CREATE TABLE `roomprice` (
  `roomPrice_ID` int(50) NOT NULL,
  `reservationID` int(50) NOT NULL,
  `rateID` varchar(251) NOT NULL,
  `Price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roomprice`
--

INSERT INTO `roomprice` (`roomPrice_ID`, `reservationID`, `rateID`, `Price`) VALUES
(4000, 1001, 'E03', 20000),
(4001, 1003, 'I01', 13000),
(4002, 1004, 'Q02', 3000),
(4003, 1006, 'U04', 24000),
(4004, 1007, 'E01', 12000),
(4005, 1008, 'P01', 20000),
(4006, 1009, 'Y01', 5000),
(4007, 1010, 'U02', 14000),
(4008, 1011, 'P04', 38000),
(4009, 1012, 'P01', 20000),
(4010, 1013, 'Y01', 5000),
(4011, 1017, 'Y01', 5000),
(4012, 1018, 'Y01', 5000),
(4013, 1021, 'Q01', 2000),
(4014, 1022, 'Y01', 5000),
(4015, 1023, 'Y01', 5000),
(4016, 1024, 'Y01', 5000),
(4017, 1025, 'Q01', 2000),
(4018, 1026, 'Y01', 5000),
(4019, 1027, 'Y01', 5000),
(4020, 1029, 'Y01', 5000),
(4021, 1033, 'Y01', 5000),
(4022, 1034, 'Y01', 5000),
(4023, 1035, 'Y01', 5000),
(4024, 1036, 'U03', 19000),
(4025, 1037, 'Y01', 5000),
(4026, 1038, 'Y01', 5000);

-- --------------------------------------------------------

--
-- Table structure for table `seasondetails`
--

CREATE TABLE `seasondetails` (
  `seasonID` varchar(251) NOT NULL,
  `seasonType` varchar(251) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `seasondetails`
--

INSERT INTO `seasondetails` (`seasonID`, `seasonType`) VALUES
('S01', 'Lean'),
('S02', 'High'),
('S03', 'Peak'),
('S04', 'Super Peak');

-- --------------------------------------------------------

--
-- Table structure for table `tblregistration`
--

CREATE TABLE `tblregistration` (
  `accNum` int(50) NOT NULL,
  `passWord` varchar(251) NOT NULL,
  `firstName` varchar(251) NOT NULL,
  `lastName` varchar(251) NOT NULL,
  `bDay` date NOT NULL,
  `Age` int(50) NOT NULL,
  `eMail` varchar(251) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblregistration`
--

INSERT INTO `tblregistration` (`accNum`, `passWord`, `firstName`, `lastName`, `bDay`, `Age`, `eMail`) VALUES
(13660001, '', '', '', '0001-01-01', 0, ''),
(13660002, '123', 'hatdog', 'gang', '1990-01-01', 34, 'hatdog@gmail.com'),
(13660003, '123', 'Jhimar', 'Motea', '2004-01-19', 20, 'jhimar@gmail.com'),
(13660004, '', '', '', '0001-01-01', 0, ''),
(13660006, '', '', '', '0001-01-01', 0, ''),
(13660007, '12341', 'emily', 'sicat', '2000-11-01', 23, 'emily@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addetails`
--
ALTER TABLE `addetails`
  ADD KEY `adOn_typeID` (`adOn_typeID`),
  ADD KEY `reservationID` (`reservationID`);

--
-- Indexes for table `adons`
--
ALTER TABLE `adons`
  ADD PRIMARY KEY (`adOn_typeID`);

--
-- Indexes for table `amenities`
--
ALTER TABLE `amenities`
  ADD PRIMARY KEY (`ame_typeID`);

--
-- Indexes for table `amenities_details`
--
ALTER TABLE `amenities_details`
  ADD KEY `reservationID` (`reservationID`);

--
-- Indexes for table `destinationdetails`
--
ALTER TABLE `destinationdetails`
  ADD PRIMARY KEY (`dTypeID`);

--
-- Indexes for table `paymentdetails`
--
ALTER TABLE `paymentdetails`
  ADD PRIMARY KEY (`paymentID`),
  ADD KEY `reservationID` (`reservationID`);

--
-- Indexes for table `ratedetails`
--
ALTER TABLE `ratedetails`
  ADD PRIMARY KEY (`rateID`),
  ADD KEY `roomtype_ID` (`roomtype_ID`),
  ADD KEY `dTYpeID` (`dTYpeID`),
  ADD KEY `ratedetails_ibfk_1` (`seasonID`);

--
-- Indexes for table `reservationdetails`
--
ALTER TABLE `reservationdetails`
  ADD PRIMARY KEY (`reservationID`),
  ADD KEY `reservation` (`accNum`);

--
-- Indexes for table `roomdetails`
--
ALTER TABLE `roomdetails`
  ADD PRIMARY KEY (`roomtype_ID`);

--
-- Indexes for table `roomprice`
--
ALTER TABLE `roomprice`
  ADD PRIMARY KEY (`roomPrice_ID`),
  ADD KEY `reservationID` (`reservationID`),
  ADD KEY `rateID` (`rateID`);

--
-- Indexes for table `seasondetails`
--
ALTER TABLE `seasondetails`
  ADD PRIMARY KEY (`seasonID`);

--
-- Indexes for table `tblregistration`
--
ALTER TABLE `tblregistration`
  ADD PRIMARY KEY (`accNum`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `paymentdetails`
--
ALTER TABLE `paymentdetails`
  MODIFY `paymentID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3140006;

--
-- AUTO_INCREMENT for table `reservationdetails`
--
ALTER TABLE `reservationdetails`
  MODIFY `reservationID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1039;

--
-- AUTO_INCREMENT for table `roomprice`
--
ALTER TABLE `roomprice`
  MODIFY `roomPrice_ID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4027;

--
-- AUTO_INCREMENT for table `tblregistration`
--
ALTER TABLE `tblregistration`
  MODIFY `accNum` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13660008;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `addetails`
--
ALTER TABLE `addetails`
  ADD CONSTRAINT `addetails_ibfk_1` FOREIGN KEY (`adOn_typeID`) REFERENCES `adons` (`adOn_typeID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `addetails_ibfk_2` FOREIGN KEY (`reservationID`) REFERENCES `reservationdetails` (`reservationID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `amenities_details`
--
ALTER TABLE `amenities_details`
  ADD CONSTRAINT `amenities_details_ibfk_1` FOREIGN KEY (`reservationID`) REFERENCES `reservationdetails` (`reservationID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `paymentdetails`
--
ALTER TABLE `paymentdetails`
  ADD CONSTRAINT `paymentdetails_ibfk_1` FOREIGN KEY (`reservationID`) REFERENCES `reservationdetails` (`reservationID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ratedetails`
--
ALTER TABLE `ratedetails`
  ADD CONSTRAINT `ratedetails_ibfk_1` FOREIGN KEY (`seasonID`) REFERENCES `seasondetails` (`seasonID`),
  ADD CONSTRAINT `ratedetails_ibfk_2` FOREIGN KEY (`roomtype_ID`) REFERENCES `roomdetails` (`roomtype_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ratedetails_ibfk_3` FOREIGN KEY (`dTYpeID`) REFERENCES `destinationdetails` (`dTypeID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `reservationdetails`
--
ALTER TABLE `reservationdetails`
  ADD CONSTRAINT `reservation` FOREIGN KEY (`accNum`) REFERENCES `tblregistration` (`accNum`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `roomprice`
--
ALTER TABLE `roomprice`
  ADD CONSTRAINT `roomprice_ibfk_1` FOREIGN KEY (`reservationID`) REFERENCES `reservationdetails` (`reservationID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `roomprice_ibfk_2` FOREIGN KEY (`rateID`) REFERENCES `ratedetails` (`rateID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
